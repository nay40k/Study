public class SpareParts {
    public static void main(String[] args) {
        String[] parts = {"Engine", "Left Door", "Right Door", "Wheels", "Oil pan", "E", "F", "G", "H" };
        for (String part : parts) {
            System.out.println(part);
        }
    }
}
